module.exports = process.env.TEST_MODE === 'auth'
